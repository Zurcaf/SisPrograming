#include <unistd.h>
#include <stdio.h>

typedef struct message{
   int type;

   int i;
   double d;
} message;

int main(){
    int fd[2];
    int i = 0;
    int ii = 9999;
    pipe(fd);

    int n = fork();
    printf("after fork %d\n", n);
    if (n== 0){
       if (fork () ==0){
	    
	    printf("child 1\n");
	    while(1){
	       message m;
	       m.type = 1;
	       m.i = i;
	       printf("\t1 printing %d bytes\n", sizeof(m)); 
	       write(fd[1], &m, sizeof(m));
	       sleep(1);
	       i++;
	    }
	 }else{
	    printf("child 2\n");
	    double x =0;
	    while(1){
	       message m;
	       m.type = 2;
	       m.d = x;
	       printf("\t2 printing %d bytes\n", sizeof(m)); 
	       write(fd[1], &m, sizeof(m));
	       sleep(1);
	       x = x + 1E-10;
	    }	    
	 }
    }else{
        printf("parent\n");
        while(1){
	   message m;
	   read(fd[0], &m, sizeof(m));
	   if(m.type==1){
	      printf("%d \n", m.i);
	   }else{
	      printf("%e \n", m.d);
	   }
	   
	   
        }

    }

}