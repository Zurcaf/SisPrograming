#include <unistd.h>
#include <stdio.h>

int main(){
    int fd[2];
    int i = 0;
    int ii = 9999;
    pipe(fd);

    int n = fork();
    printf("after fork %d\n", n);
    if (n== 0){
       if (fork () ==0){
	    
	    printf("child 1\n");
	    while(1){
	       printf("\t1 printing %d bytes %d\n", sizeof(i), i); 
	       write(fd[1], &i, sizeof(i));
	       sleep(1);
	       i++;
	    }
	 }else{
	    printf("child 2\n");
	    double x =0;
	    while(1){
	       printf("\t2 printing %d bytes %e\n", sizeof(x), x); 
	       write(fd[1], &x, sizeof(x));
	       sleep(1);
	       x = x + 1E-10;
	    }	    
	 }
    }else{
        printf("parent\n");
        while(1){
            read(fd[0], &ii, sizeof(ii));
            printf("%d \n", ii);
        }

    }

}