#include <unistd.h>
#include <stdio.h>

int main(){
    int fd[2];
    int i = 0;
    int ii = 9999;
    pipe(fd);

	close(0);
	dup(fd[0]);
	if(fork() !=0){
		while(1){
			char line[11];
			int n;
			read(0, &n, sizeof(n));
			printf("%d\n", n);
			i++;
		}
	}else{
		int n =0;
		while(1){
			write(fd[1], &n, sizeof(n));
			sleep(1);
			n++;
		}

	}
}