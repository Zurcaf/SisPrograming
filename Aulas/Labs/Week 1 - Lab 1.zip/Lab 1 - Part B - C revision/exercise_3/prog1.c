#include "lib.h"

int main(){
	func_1();
	func_2();
}
